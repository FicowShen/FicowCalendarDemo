//
//  CalendarView_iOS.h
//  CalendarView iOS
//
//  Created by Rémy DA COSTA FARO on 22/04/2018.
//  Copyright © 2018 Karmadust. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CalendarView_iOS.
FOUNDATION_EXPORT double CalendarView_iOSVersionNumber;

//! Project version string for CalendarView_iOS.
FOUNDATION_EXPORT const unsigned char CalendarView_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CalendarView_iOS/PublicHeader.h>


