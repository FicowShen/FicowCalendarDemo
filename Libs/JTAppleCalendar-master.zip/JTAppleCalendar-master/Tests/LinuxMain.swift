import XCTest

import JTAppleCalendarTests

var tests = [XCTestCaseEntry]()
tests += JTAppleCalendarTests.allTests()
XCTMain(tests)
