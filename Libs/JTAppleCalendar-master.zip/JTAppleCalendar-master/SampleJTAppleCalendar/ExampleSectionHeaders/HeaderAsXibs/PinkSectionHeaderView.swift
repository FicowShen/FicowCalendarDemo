//
//  PinkSectionHeaderView.swift
//  JTAppleCalendar
//
//  Created by JayT on 2016-05-11.
//  Copyright © 2016 CocoaPods. All rights reserved.
//

import UIKit
import JTAppleCalendar

class PinkSectionHeaderView: JTACMonthReusableView {
    @IBOutlet var title: UILabel!
}
