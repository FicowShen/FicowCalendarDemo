//
//  AppDelegate.h
//  Example-TodayExtension
//
//  Created by dingwenchao on 9/6/16.
//  Copyright © 2016 dingwenchao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

